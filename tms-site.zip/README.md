# Texas Mechanical Services, LLC - Website Mockup

Files: `index.html`, `style.css`, `script.js` and the `assets/` folder (keep them together).

## Publish with GitHub Pages
1. Upload everything to the root of a repository.
2. Settings > Pages > branch `main`, folder `/ (root)` > Save.
3. Site appears at `https://<username>.github.io/<repo>/`.

The quote form is a demo and does not send data.
